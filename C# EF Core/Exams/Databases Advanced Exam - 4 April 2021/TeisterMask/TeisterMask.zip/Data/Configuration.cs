﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-S39TTSS\SQLEXPRESS;Database=TeisterMask;
                                                    Trusted_Connection=True";
    }
}
